package algorithms.mazeGenerators;

/**
 * Created by Noah on 4/4/2017.
 */
public final class  WallType {

    //public static char wall = '\u2588';
    //public static char passage = '\u00A0';
    //public static char passage = '\u2591';

    /**
     * class that defines type of cell(wall/passage)
     */
    public static int wall = 1;
    public static int passage = 0;
}
